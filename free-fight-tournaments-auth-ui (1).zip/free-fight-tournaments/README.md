# Free Fight Tournaments — Prototype v0.1

An English-only, blue-and-white responsive front-end prototype for a Pakistan-focused Free Fire tournament website.

## What works in this prototype

- Home dashboard, featured tournaments, announcements and five original SVG visuals
- Solo, Duo and Squad tournament listings with filters
- Demo player balance and one-click tournament join with entry-fee deduction
- Demo deposit requests, withdrawal requests, admin approval/rejection
- Demo prize crediting, tournament creation, status changes and room-detail release
- Demo player activity and transaction history
- Admin Control Center layout and WhatsApp support placeholder
- Saves demo state in this browser's `localStorage`

## Important safety limitation

**This is a front-end demo, not a production money-handling website. Do not use real money or real payment details in it.**

The demo has no server, real database, secure login, payment gateway, server-side wallet ledger, identity checks, or admin authorization. Anyone with browser access can open the demo Admin Control Center, and local browser data can be edited or cleared. Demo balances are not real money.

The sample login details shown in the UI are illustrative only; no real signup or login system exists yet.

## Run locally

### Easiest option
1. Extract the ZIP.
2. Open `index.html` in a modern browser.

### Better local preview
If Python is installed, open a terminal in this folder and run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Next step before launch: production backend

A live version should use a server and database. Recommended beginner-friendly architecture:

- Front end: this UI, upgraded as needed
- Backend: Node.js + Express (or a managed backend with server-side rules)
- Database: PostgreSQL / Supabase
- Authentication: verified email/password, secure sessions, password reset, rate limits
- Admin permissions: server-enforced roles; only the main admin can add/remove admins
- Wallet: server-side ledger with immutable transaction records and database transactions
- Tournament join: atomic balance check + coin deduction + seat reservation; unique constraints prevent duplicate joins
- Deposits: admin verifies the payment in the provider's official dashboard before crediting coins
- Withdrawals: pending request, admin review, payout outside the demo, and a recorded final status
- Room details: server checks that the player is eligible before showing the ID/password at the configured release time
- Logs and backups: record admin actions and back up the database

## Payment methods

The prototype only simulates requests. It does not connect to Easypaisa, JazzCash, or a bank.

For a real launch:
1. Decide which provider/account you can legally use for a tournament business.
2. Contact the provider and ask for merchant/business onboarding and API or checkout access.
3. Keep API secrets on the server only; never put secrets in HTML or JavaScript.
4. Use the provider's signed webhook/callback and verify its signature server-side.
5. Credit a deposit only once, after verifying a successful payment. Store the provider transaction ID with a unique constraint to prevent duplicate credits.
6. For withdrawals, use an approved payout API if available to your merchant account; otherwise treat it as a manual admin-reviewed process.
7. Test with sandbox/test credentials first, then ask the provider to approve production use.

Availability, eligibility, fees, and APIs vary by provider and account. Do not assume all three payment methods offer public APIs or automated withdrawals.

## Suggested build order

1. Create backend project and database schema.
2. Add real player registration, email login, password reset and admin role permissions.
3. Implement wallet ledger and atomic join transaction.
4. Add deposit proof / reference workflow and admin approval.
5. Add withdrawal workflow and audit log.
6. Integrate an approved payment gateway if available.
7. Add room release controls, results, announcements, support settings and image upload.
8. Test authorization, duplicate requests, concurrent joins, negative balances, payment webhook replay and backups.
9. Deploy backend and front end; configure HTTPS, domain, environment variables and database backups.

## Coin rule and no-refund policy

The prototype uses 1 coin = Rs. 1 and no refunds for voluntary tournament departure, as requested. Before accepting real payments, publish clear terms, refund rules for cancelled matches, prize rules, age restrictions, and support contact details. Check local laws and game/platform tournament rules with a qualified professional before taking entry fees or paying prizes.


## Backend starter added

See `BACKEND_SETUP.md`, `supabase/migrations/0001_initial_schema.sql`, `.env.example`, and `supabaseClient.example.js`. These files provide a Supabase database/security foundation, but the current static UI remains a demo and is not yet connected to real authentication or payments. Do not accept real money yet.

## Supabase authentication UI (build v0.2)

The project now includes a Vite-based authentication screen in English with:

- Email/password sign-in
- Email/password account creation with display name and password confirmation
- Email confirmation flow (requires confirmation to be enabled in Supabase Auth settings)
- Google OAuth button (requires Google provider credentials in Supabase)
- Password reset email request
- Sign-out and existing-session restoration
- A profile-role check that hides the prototype admin navigation for non-admin accounts

**Not yet integrated:** the main tournament, wallet, deposit, withdrawal, prize and admin actions still use the prototype's localStorage data. Supabase authentication does not make those features production-ready. Do not use real money or sensitive payment information.

### Run the authentication UI locally

1. Install Node.js LTS (npm is included).
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env`.
4. In Supabase, open **Project Settings → API** and copy the Project URL and the public anon/publishable key into `.env` as `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
5. Run the SQL migration in `supabase/migrations/0001_initial_schema.sql` using Supabase SQL Editor.
6. Configure the Auth settings described in `BACKEND_SETUP.md` below, then run `npm run dev`.
7. Open the local URL printed by Vite. Do not open `index.html` directly; Vite is needed to load the Supabase module and environment variables.

Never put a Supabase `service_role` key in `.env` for this frontend, in source code, or in a public repository. Only the public anon/publishable key belongs in the browser, and database RLS must remain enabled.
