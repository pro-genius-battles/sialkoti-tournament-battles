/*
  Example only — install @supabase/supabase-js and configure environment variables
  in a Vite frontend before use. This file is intentionally not imported by app.js,
  so the existing prototype remains clearly in demo mode.
*/
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase public configuration. See .env.example.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

// Example calls after a user has signed in:
// const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { display_name } } });
// const { data, error } = await supabase.auth.signInWithPassword({ email, password });
// const { data, error } = await supabase.rpc('join_tournament', { p_tournament_id: tournamentId });
// const { data, error } = await supabase.rpc('request_withdrawal', {
//   p_amount_coins: amount, p_method: method, p_account_title: accountTitle, p_account_number: accountNumber
// });
//
// Do not call admin RPCs from an unauthenticated session. PostgreSQL checks admin role too.
// Never put the Supabase service_role key here.
