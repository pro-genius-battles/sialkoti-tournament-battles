import { supabase, supabaseConfigured } from './supabaseClient.js';

const authScreen = document.getElementById('authScreen');
const appShell = document.getElementById('appShell');
const messageBox = document.getElementById('authMessage');
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');
const resetPasswordForm = document.getElementById('resetPasswordForm');
const authCard = document.querySelector('.auth-card');
const authDivider = document.getElementById('authDivider');
const authTitle = document.getElementById('authTitle');
const authSubtitle = document.getElementById('authSubtitle');
const googleButton = document.getElementById('googleAuth');
const configNote = document.getElementById('authConfigNote');
let currentMode = 'login';
let activeUser = null;

function showMessage(message, kind = 'info') {
  messageBox.hidden = !message;
  messageBox.textContent = message;
  messageBox.className = `auth-message ${kind}`;
}

function setBusy(form, busy, busyText = 'Please wait…') {
  const button = form.querySelector('button[type="submit"]');
  if (!button) return;
  if (busy) {
    button.dataset.originalText = button.textContent;
    button.disabled = true;
    button.textContent = busyText;
  } else {
    button.disabled = false;
    if (button.dataset.originalText) button.textContent = button.dataset.originalText;
  }
}

function setMode(mode) {
  currentMode = mode;
  const isSignup = mode === 'signup';
  loginForm.hidden = isSignup;
  signupForm.hidden = !isSignup;
  resetPasswordForm.hidden = true;
  authCard.classList.remove('recovery-mode');
  authDivider.hidden = !isSignup;
  googleButton.hidden = !isSignup;
  document.querySelectorAll('[data-auth-mode]').forEach(button => {
    button.hidden = false;
    const active = button.dataset.authMode === mode;
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', String(active));
  });
  authTitle.textContent = isSignup ? 'Create your player account' : 'Sign in to your account';
  authSubtitle.textContent = isSignup
    ? 'Create an account with email, password, or Google.'
    : 'Use your email and password to continue.';
  showMessage('');
}

function showRecoveryForm() {
  authScreen.hidden = false;
  appShell.hidden = true;
  loginForm.hidden = true;
  signupForm.hidden = true;
  resetPasswordForm.hidden = false;
  document.querySelectorAll('[data-auth-mode]').forEach(button => { button.hidden = true; });
  authDivider.hidden = true;
  googleButton.hidden = true;
  authCard.classList.add('recovery-mode');
  authTitle.textContent = 'Choose a new password';
  authSubtitle.textContent = 'Set a new password for your account.';
  showMessage('Password reset link verified. Enter a new password below.', 'success');
}

function showSignedOut(message = '', kind = 'info') {
  activeUser = null;
  authScreen.hidden = false;
  appShell.hidden = true;
  configNote.hidden = supabaseConfigured;
  if (message) showMessage(message, kind);
  document.body.classList.add('auth-active');
}

async function showSignedIn(user) {
  activeUser = user;
  authScreen.hidden = true;
  appShell.hidden = false;
  document.body.classList.remove('auth-active');
  const name = user.user_metadata?.display_name || user.user_metadata?.full_name || user.email?.split('@')[0] || 'Player';
  const username = document.getElementById('topUsername');
  const roleLabel = document.getElementById('topUserRole');
  const avatar = document.querySelector('#profileButton .avatar');
  if (username) username.textContent = name;
  if (avatar) avatar.textContent = name.trim().charAt(0).toUpperCase() || 'P';
  if (roleLabel) roleLabel.textContent = 'Authenticated · demo data';

  // Hide the prototype's admin controls for normal players. This is UI hygiene only;
  // actual authorization must be enforced by database RLS and server-side functions.
  const { data: profile, error } = await supabase
    .from('profiles')
    .select('role, display_name')
    .eq('id', user.id)
    .maybeSingle();
  const isAdmin = !error && profile?.role === 'admin';
  document.querySelectorAll('.admin-nav').forEach(el => { el.hidden = !isAdmin; });
  const adminView = document.getElementById('view-admin');
  if (!isAdmin && adminView?.classList.contains('active')) {
    document.querySelector('[data-view="home"]')?.click();
  }
  if (roleLabel) roleLabel.textContent = `${isAdmin ? 'Admin' : 'Player'} · auth on, app demo`;
}

function friendlyError(error) {
  const message = error?.message || 'Something went wrong. Please try again.';
  if (/invalid login credentials/i.test(message)) return 'Email or password is incorrect.';
  if (/email not confirmed/i.test(message)) return 'Please verify your email using the link we sent before signing in.';
  if (/user already registered/i.test(message)) return 'An account with this email already exists. Try signing in.';
  if (/password should be at least/i.test(message)) return 'Use a password that meets the minimum length requirement.';
  return message;
}

function ensureConfigured() {
  if (supabaseConfigured) return true;
  showMessage('Supabase is not configured yet. Follow BACKEND_SETUP.md, add the project URL and public key to .env, then restart the server.', 'error');
  return false;
}

document.querySelectorAll('[data-auth-mode]').forEach(button => {
  button.addEventListener('click', () => setMode(button.dataset.authMode));
});

loginForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (!ensureConfigured()) return;
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;
  setBusy(loginForm, true, 'Signing in…');
  showMessage('');
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  setBusy(loginForm, false);
  if (error) {
    showMessage(friendlyError(error), 'error');
    return;
  }
  if (data.user && !data.session) {
    showMessage('Check your email and confirm your address before signing in.', 'success');
    return;
  }
  showMessage('Signed in successfully.', 'success');
});

signupForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (!ensureConfigured()) return;
  const name = document.getElementById('signupName').value.trim();
  const email = document.getElementById('signupEmail').value.trim();
  const password = document.getElementById('signupPassword').value;
  const confirm = document.getElementById('signupConfirm').value;
  if (password !== confirm) {
    showMessage('The passwords do not match.', 'error');
    return;
  }
  setBusy(signupForm, true, 'Creating account…');
  showMessage('');
  const emailRedirectTo = `${window.location.origin}${window.location.pathname}`;
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo,
      data: { display_name: name },
    },
  });
  setBusy(signupForm, false);
  if (error) {
    showMessage(friendlyError(error), 'error');
    return;
  }
  if (data.session) {
    // If email confirmation is disabled in Supabase, a session may be created here.
    showMessage('Account created. Supabase returned a session; confirm that email verification is enabled in your project settings.', 'success');
    return;
  }
  showMessage('Account created. Check your inbox for the verification link before signing in. If it does not arrive, check spam or resend the confirmation email.', 'success');
  signupForm.reset();
  setMode('login');
  document.getElementById('loginEmail').value = email;
});

resetPasswordForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (!ensureConfigured()) return;
  const password = document.getElementById('resetPassword').value;
  const confirmation = document.getElementById('resetPasswordConfirm').value;
  if (password !== confirmation) {
    showMessage('The passwords do not match.', 'error');
    return;
  }
  setBusy(resetPasswordForm, true, 'Updating password…');
  const { error } = await supabase.auth.updateUser({ password });
  setBusy(resetPasswordForm, false);
  if (error) {
    showMessage(friendlyError(error), 'error');
    return;
  }
  resetPasswordForm.reset();
  await supabase.auth.signOut();
  document.querySelectorAll('[data-auth-mode]').forEach(button => { button.hidden = false; });
  setMode('login');
  showSignedOut('Password updated. Sign in with your new password.', 'success');
});

googleButton.addEventListener('click', async () => {
  if (!ensureConfigured()) return;
  googleButton.disabled = true;
  showMessage('Redirecting to Google…');
  const { error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: `${window.location.origin}${window.location.pathname}` },
  });
  if (error) {
    googleButton.disabled = false;
    showMessage(friendlyError(error), 'error');
  }
});

document.getElementById('forgotPassword').addEventListener('click', async () => {
  if (!ensureConfigured()) return;
  const email = document.getElementById('loginEmail').value.trim();
  if (!email) {
    showMessage('Enter your email address first, then choose Forgot password.', 'error');
    document.getElementById('loginEmail').focus();
    return;
  }
  const redirectTo = `${window.location.origin}${window.location.pathname}`;
  const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo });
  if (error) showMessage(friendlyError(error), 'error');
  else showMessage('If an account exists for that email, a password-reset link will be sent.', 'success');
});

document.getElementById('signOutButton').addEventListener('click', async () => {
  if (!supabase || !activeUser) return;
  const button = document.getElementById('signOutButton');
  button.disabled = true;
  const { error } = await supabase.auth.signOut();
  button.disabled = false;
  if (error) {
    window.alert(`Could not sign out: ${friendlyError(error)}`);
    return;
  }
  showSignedOut('You have signed out.');
});

if (!supabaseConfigured) {
  showSignedOut();
  configNote.hidden = false;
  showMessage('Supabase setup is required before sign-in and signup can work.', 'error');
} else {
  showSignedOut();
  supabase.auth.getSession().then(({ data, error }) => {
    if (error) showMessage(friendlyError(error), 'error');
    if (data?.session?.user) showSignedIn(data.session.user);
  });
  supabase.auth.onAuthStateChange((event, session) => {
    if (event === 'PASSWORD_RECOVERY') {
      setTimeout(() => showRecoveryForm(), 0);
    } else if (session?.user) {
      // Defer profile lookup outside the auth callback to avoid blocking auth events.
      setTimeout(() => showSignedIn(session.user), 0);
    } else if (event === 'SIGNED_OUT') {
      showSignedOut();
    }
  });
}
