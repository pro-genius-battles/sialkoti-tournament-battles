
-- Free Fight Tournaments: Supabase/PostgreSQL starter schema
-- Apply in Supabase SQL Editor only after creating a project.
-- IMPORTANT: Never expose a service-role key in browser code.

create extension if not exists pgcrypto;

do $$ begin
  create type public.app_role as enum ('player', 'admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.tournament_mode as enum ('Solo', 'Duo', 'Squad', 'Custom');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.tournament_status as enum ('Upcoming', 'Live', 'Completed', 'Cancelled');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.transaction_kind as enum ('deposit', 'withdrawal', 'tournament_entry', 'prize', 'refund', 'adjustment');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.request_status as enum ('pending', 'approved', 'rejected', 'paid');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Player',
  email text,
  country_code text not null default 'PK',
  role public.app_role not null default 'player',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.wallets (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  balance_coins bigint not null default 0 check (balance_coins >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.tournaments (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  mode public.tournament_mode not null default 'Solo',
  entry_fee_coins bigint not null check (entry_fee_coins >= 0),
  max_players integer not null check (max_players > 0),
  prize_pool_coins bigint not null default 0 check (prize_pool_coins >= 0),
  status public.tournament_status not null default 'Upcoming',
  image_path text,
  starts_at timestamptz,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tournament_entries (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete restrict,
  user_id uuid not null references public.profiles(id) on delete restrict,
  entry_fee_coins bigint not null check (entry_fee_coins >= 0),
  joined_at timestamptz not null default now(),
  unique (tournament_id, user_id)
);

-- Room credentials are deliberately stored separately so public tournament listings
-- never expose them. Participants see them only after the admin release time.
create table if not exists public.tournament_room_secrets (
  tournament_id uuid primary key references public.tournaments(id) on delete cascade,
  room_id text not null,
  room_password text not null,
  reveal_at timestamptz,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

create table if not exists public.wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete restrict,
  kind public.transaction_kind not null,
  amount_coins bigint not null check (amount_coins <> 0),
  status text not null default 'completed' check (status in ('pending','completed','rejected','reversed')),
  description text not null default '',
  reference text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  unique (reference)
);

create table if not exists public.deposit_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete restrict,
  amount_coins bigint not null check (amount_coins > 0),
  method text not null check (method in ('Easypaisa','JazzCash','Bank transfer')),
  payment_reference text not null,
  proof_path text,
  status public.request_status not null default 'pending',
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete restrict,
  amount_coins bigint not null check (amount_coins > 0),
  method text not null check (method in ('Easypaisa','JazzCash','Bank transfer')),
  account_title text not null,
  account_number text not null,
  status public.request_status not null default 'pending',
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.tournament_results (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete restrict,
  user_id uuid not null references public.profiles(id) on delete restrict,
  placement integer check (placement > 0),
  kills integer not null default 0 check (kills >= 0),
  prize_coins bigint not null default 0 check (prize_coins >= 0),
  notes text not null default '',
  entered_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  unique (tournament_id, user_id)
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  published boolean not null default false,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.app_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

create table if not exists public.admin_audit_logs (
  id bigint generated always as identity primary key,
  admin_id uuid not null references public.profiles(id),
  action text not null,
  target_type text not null,
  target_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Create profile + empty wallet on signup. Role is always player; never trust user metadata for roles.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name, email, country_code, role)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data ->> 'display_name',''), 'Player'),
    new.email,
    'PK',
    'player'
  ) on conflict (id) do nothing;
  insert into public.wallets (user_id, balance_coins) values (new.id, 0)
  on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists(select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin');
$$;

-- A user can join only once. Seat reservation and wallet deduction occur in one database transaction.
create or replace function public.join_tournament(p_tournament_id uuid)
returns uuid language plpgsql security definer set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_t public.tournaments%rowtype;
  v_entry uuid;
  v_count integer;
begin
  if v_user is null then raise exception 'Please sign in first'; end if;

  select * into v_t from public.tournaments where id = p_tournament_id for update;
  if not found then raise exception 'Tournament not found'; end if;
  if v_t.status <> 'Upcoming' then raise exception 'Tournament is not open for joining'; end if;
  if v_t.starts_at is not null and v_t.starts_at <= now() then raise exception 'Registration is closed'; end if;

  select count(*) into v_count from public.tournament_entries where tournament_id = p_tournament_id;
  if v_count >= v_t.max_players then raise exception 'Tournament is full'; end if;
  if exists(select 1 from public.tournament_entries where tournament_id=p_tournament_id and user_id=v_user) then
    raise exception 'You already joined this tournament';
  end if;

  update public.wallets set balance_coins = balance_coins - v_t.entry_fee_coins, updated_at=now()
  where user_id=v_user and balance_coins >= v_t.entry_fee_coins;
  if not found then raise exception 'Not enough coins'; end if;

  insert into public.tournament_entries(tournament_id,user_id,entry_fee_coins)
  values(p_tournament_id,v_user,v_t.entry_fee_coins) returning id into v_entry;

  if v_t.entry_fee_coins > 0 then
    insert into public.wallet_transactions(user_id,kind,amount_coins,status,description,reference)
    values(v_user,'tournament_entry',-v_t.entry_fee_coins,'completed',
           'Entry fee: ' || v_t.title, 'entry:' || v_entry::text);
  end if;
  return v_entry;
end;
$$;

-- Deposit approval is an admin-only, single-use operation.
create or replace function public.review_deposit(p_request_id uuid, p_approve boolean)
returns void language plpgsql security definer set search_path = ''
as $$
declare r public.deposit_requests%rowtype;
begin
  if not public.is_admin() then raise exception 'Admin permission required'; end if;
  select * into r from public.deposit_requests where id=p_request_id for update;
  if not found or r.status <> 'pending' then raise exception 'Request not found or already reviewed'; end if;

  update public.deposit_requests set status=case when p_approve then 'approved'::public.request_status else 'rejected'::public.request_status end,
    reviewed_by=auth.uid(), reviewed_at=now() where id=r.id;

  if p_approve then
    update public.wallets set balance_coins=balance_coins+r.amount_coins, updated_at=now() where user_id=r.user_id;
    insert into public.wallet_transactions(user_id,kind,amount_coins,status,description,reference,created_by)
    values(r.user_id,'deposit',r.amount_coins,'completed','Deposit approved: '||r.method,
           'deposit:'||r.id::text,auth.uid());
  end if;
  insert into public.admin_audit_logs(admin_id,action,target_type,target_id,details)
  values(auth.uid(),case when p_approve then 'approve_deposit' else 'reject_deposit' end,'deposit_request',r.id::text,
         jsonb_build_object('amount_coins',r.amount_coins,'user_id',r.user_id));
end;
$$;

-- Withdrawal amount is reserved immediately. Rejection returns it once; approval marks it approved
-- but does not send money automatically. A real payout integration is a separate approved step.
create or replace function public.request_withdrawal(
  p_amount_coins bigint, p_method text, p_account_title text, p_account_number text
) returns uuid language plpgsql security definer set search_path = ''
as $$
declare v_user uuid := auth.uid(); v_id uuid;
begin
  if v_user is null then raise exception 'Please sign in first'; end if;
  if p_amount_coins <= 0 then raise exception 'Amount must be greater than zero'; end if;
  if p_method not in ('Easypaisa','JazzCash','Bank transfer') then raise exception 'Unsupported payment method'; end if;
  if length(trim(coalesce(p_account_title,''))) < 2 or length(trim(coalesce(p_account_number,''))) < 5 then
    raise exception 'Please provide valid payout details';
  end if;

  update public.wallets set balance_coins=balance_coins-p_amount_coins,updated_at=now()
  where user_id=v_user and balance_coins>=p_amount_coins;
  if not found then raise exception 'Not enough coins'; end if;

  insert into public.withdrawal_requests(user_id,amount_coins,method,account_title,account_number)
  values(v_user,p_amount_coins,p_method,trim(p_account_title),trim(p_account_number)) returning id into v_id;
  insert into public.wallet_transactions(user_id,kind,amount_coins,status,description,reference)
  values(v_user,'withdrawal',-p_amount_coins,'pending','Withdrawal request: '||p_method,'withdrawal:'||v_id::text);
  return v_id;
end;
$$;

create or replace function public.review_withdrawal(p_request_id uuid, p_approve boolean)
returns void language plpgsql security definer set search_path = ''
as $$
declare r public.withdrawal_requests%rowtype;
begin
  if not public.is_admin() then raise exception 'Admin permission required'; end if;
  select * into r from public.withdrawal_requests where id=p_request_id for update;
  if not found or r.status <> 'pending' then raise exception 'Request not found or already reviewed'; end if;

  update public.withdrawal_requests set status=case when p_approve then 'approved'::public.request_status else 'rejected'::public.request_status end,
    reviewed_by=auth.uid(),reviewed_at=now() where id=r.id;
  if not p_approve then
    update public.wallets set balance_coins=balance_coins+r.amount_coins,updated_at=now() where user_id=r.user_id;
    insert into public.wallet_transactions(user_id,kind,amount_coins,status,description,reference,created_by)
    values(r.user_id,'adjustment',r.amount_coins,'completed','Rejected withdrawal returned','withdrawal-return:'||r.id::text,auth.uid());
  end if;
  insert into public.admin_audit_logs(admin_id,action,target_type,target_id,details)
  values(auth.uid(),case when p_approve then 'approve_withdrawal' else 'reject_withdrawal' end,'withdrawal_request',r.id::text,
         jsonb_build_object('amount_coins',r.amount_coins,'user_id',r.user_id,
                            'note','Approval does not itself transfer money'));
end;
$$;

create or replace function public.credit_prize(
  p_user_id uuid, p_tournament_id uuid, p_amount_coins bigint, p_placement integer default null, p_kills integer default 0, p_notes text default ''
) returns uuid language plpgsql security definer set search_path = ''
as $$
declare v_result uuid;
begin
  if not public.is_admin() then raise exception 'Admin permission required'; end if;
  if p_amount_coins < 0 or p_kills < 0 then raise exception 'Invalid prize or kills'; end if;
  insert into public.tournament_results(tournament_id,user_id,placement,kills,prize_coins,notes,entered_by)
  values(p_tournament_id,p_user_id,p_placement,p_kills,p_amount_coins,coalesce(p_notes,''),auth.uid())
  on conflict (tournament_id,user_id) do update set placement=excluded.placement,kills=excluded.kills,
    prize_coins=excluded.prize_coins,notes=excluded.notes,entered_by=excluded.entered_by
  returning id into v_result;

  -- Credit prize only once per tournament/user. If changing a result later, reconcile manually;
  -- do not call this function repeatedly for the same winner without implementing adjustment logic.
  if not exists(select 1 from public.wallet_transactions where reference='prize:'||v_result::text) and p_amount_coins > 0 then
    update public.wallets set balance_coins=balance_coins+p_amount_coins,updated_at=now() where user_id=p_user_id;
    insert into public.wallet_transactions(user_id,kind,amount_coins,status,description,reference,created_by)
    values(p_user_id,'prize',p_amount_coins,'completed','Tournament prize','prize:'||v_result::text,auth.uid());
  end if;
  insert into public.admin_audit_logs(admin_id,action,target_type,target_id,details)
  values(auth.uid(),'credit_prize','tournament_result',v_result::text,jsonb_build_object('user_id',p_user_id,'amount_coins',p_amount_coins));
  return v_result;
end;
$$;

-- Row-level security: public can view published tournament data; private records are owner/admin only.
alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.tournaments enable row level security;
alter table public.tournament_entries enable row level security;
alter table public.tournament_room_secrets enable row level security;
alter table public.wallet_transactions enable row level security;
alter table public.deposit_requests enable row level security;
alter table public.withdrawal_requests enable row level security;
alter table public.tournament_results enable row level security;
alter table public.announcements enable row level security;
alter table public.app_settings enable row level security;
alter table public.admin_audit_logs enable row level security;

drop policy if exists "profiles read self or admin" on public.profiles;
create policy "profiles read self or admin" on public.profiles for select to authenticated
using (id=auth.uid() or public.is_admin());
drop policy if exists "profiles update self basic fields" on public.profiles;
create policy "profiles update self basic fields" on public.profiles for update to authenticated
using (id=auth.uid()) with check (id=auth.uid() and role='player' and country_code='PK');

drop policy if exists "wallet read self or admin" on public.wallets;
create policy "wallet read self or admin" on public.wallets for select to authenticated
using (user_id=auth.uid() or public.is_admin());

drop policy if exists "tournaments public read" on public.tournaments;
create policy "tournaments public read" on public.tournaments for select to anon, authenticated using (true);
drop policy if exists "tournaments admin insert" on public.tournaments;
create policy "tournaments admin insert" on public.tournaments for insert to authenticated with check (public.is_admin());
drop policy if exists "tournaments admin update" on public.tournaments;
create policy "tournaments admin update" on public.tournaments for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "tournaments admin delete" on public.tournaments;
create policy "tournaments admin delete" on public.tournaments for delete to authenticated using (public.is_admin());

drop policy if exists "entries own or admin" on public.tournament_entries;
create policy "entries own or admin" on public.tournament_entries for select to authenticated
using (user_id=auth.uid() or public.is_admin());

drop policy if exists "room secrets eligible players or admin" on public.tournament_room_secrets;
create policy "room secrets eligible players or admin" on public.tournament_room_secrets for select to authenticated
using (
  public.is_admin()
  or (
    reveal_at is not null and reveal_at <= now()
    and exists (
      select 1 from public.tournament_entries e
      where e.tournament_id = tournament_room_secrets.tournament_id and e.user_id = auth.uid()
    )
  )
);
drop policy if exists "room secrets admin manage" on public.tournament_room_secrets;
create policy "room secrets admin manage" on public.tournament_room_secrets for all to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "transactions own or admin" on public.wallet_transactions;
create policy "transactions own or admin" on public.wallet_transactions for select to authenticated
using (user_id=auth.uid() or public.is_admin());

drop policy if exists "deposit requests own or admin" on public.deposit_requests;
create policy "deposit requests own or admin" on public.deposit_requests for select to authenticated
using (user_id=auth.uid() or public.is_admin());
drop policy if exists "deposit request own insert" on public.deposit_requests;
create policy "deposit request own insert" on public.deposit_requests for insert to authenticated
with check (user_id=auth.uid() and status='pending' and reviewed_by is null and reviewed_at is null);

drop policy if exists "withdrawal requests own or admin" on public.withdrawal_requests;
create policy "withdrawal requests own or admin" on public.withdrawal_requests for select to authenticated
using (user_id=auth.uid() or public.is_admin());

drop policy if exists "results public read" on public.tournament_results;
create policy "results public read" on public.tournament_results for select to anon, authenticated using (true);
drop policy if exists "announcements published read" on public.announcements;
create policy "announcements published read" on public.announcements for select to anon, authenticated
using (published=true or public.is_admin());
drop policy if exists "announcements admin manage" on public.announcements;
create policy "announcements admin manage" on public.announcements for all to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "settings public read" on public.app_settings;
create policy "settings public read" on public.app_settings for select to anon, authenticated
using (key in ('site_name','support_whatsapp','announcement') or public.is_admin());
drop policy if exists "settings admin manage" on public.app_settings;
create policy "settings admin manage" on public.app_settings for all to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "audit admin read" on public.admin_audit_logs;
create policy "audit admin read" on public.admin_audit_logs for select to authenticated using (public.is_admin());

-- Only RPCs may change balances. No direct client-side writes to wallets or transaction ledger.
revoke insert, update, delete on public.wallets from anon, authenticated;
revoke insert, update, delete on public.wallet_transactions from anon, authenticated;
revoke insert, update, delete on public.tournament_entries from anon, authenticated;
revoke insert, update, delete on public.withdrawal_requests from anon, authenticated;
revoke insert, update, delete on public.tournament_results from anon, authenticated;
revoke insert, update, delete on public.admin_audit_logs from anon, authenticated;

grant execute on function public.join_tournament(uuid) to authenticated;
grant execute on function public.review_deposit(uuid,boolean) to authenticated;
grant execute on function public.request_withdrawal(bigint,text,text,text) to authenticated;
grant execute on function public.review_withdrawal(uuid,boolean) to authenticated;
grant execute on function public.credit_prize(uuid,uuid,bigint,integer,integer,text) to authenticated;

-- Bootstrap settings. These do not enable a payment gateway.
insert into public.app_settings(key,value) values
 ('site_name',to_jsonb('Free Fight Tournaments'::text)),
 ('support_whatsapp',to_jsonb(''::text)),
 ('announcement',to_jsonb('Welcome to Free Fight Tournaments.'::text))
on conflict (key) do nothing;
