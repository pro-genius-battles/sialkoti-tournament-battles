# Free Fight Tournaments — Backend Starter (Supabase)

This is the next build step for the English-only Free Fight Tournaments prototype.

## What this package adds

- PostgreSQL schema for profiles, wallet balances, tournaments, entries, transaction ledger, deposit and withdrawal requests, results, announcements, settings and admin audit logs.
- Signup trigger creates a player profile and an empty wallet. New users are always `player`; browser metadata cannot grant admin rights.
- Row Level Security policies for owner/admin access.
- Server-side SQL functions for atomic tournament joining, deposit review, withdrawal requests/review and prize crediting.
- Audit log entries for admin money actions.

## What is NOT active yet

- The existing `index.html` + `app.js` still runs in demo/localStorage mode. It does not call this backend yet.
- No real authentication is connected to the UI.
- No live Easypaisa, JazzCash, bank API, payment gateway, or automated payout is connected.
- Deposit approval is a manual admin action; the admin must independently verify the payment in the official provider/bank channel before approving.
- Withdrawal approval does not transfer money; a human must make the payout and record it.
- Do not accept real money until integration, security review, terms, and local compliance checks are complete.

## Setup

1. Create a Supabase project at https://supabase.com/.
2. Open the project's **SQL Editor**.
3. Paste and run `supabase/migrations/0001_initial_schema.sql`.
4. In **Authentication → Providers**, enable Email. Configure email confirmation and password-reset settings for your intended launch.
5. Create your own account through Supabase Auth (once the UI is connected).
6. Find that account's UUID in **Authentication → Users**.
7. In SQL Editor, promote only your own account to admin. Replace the UUID:
   ```sql
   update public.profiles
   set role = 'admin'
   where id = 'YOUR_AUTH_USER_UUID';
   ```
   Do not let users choose their own role. Keep a record of who has admin access.
8. Save the Supabase Project URL and public anon/publishable key in the frontend's environment config when the UI is integrated. `.env.example` shows the variable names.
9. Never expose the `service_role` key. It bypasses RLS and belongs only in trusted server-side environments.

## Important current limitation

The schema is a backend foundation, not a completed integration. The current static prototype cannot securely use admin functions until real Supabase authentication is wired into the UI. The UI must be changed to call Supabase Auth and RPCs instead of localStorage state.

## Money and wallet rules

- The database stores coins as integer values. `1 coin = Rs. 1` is a display/business rule, not a guarantee that a coin is withdrawable cash.
- `join_tournament()` locks the tournament row and updates the wallet inside one transaction, so a concurrent request cannot oversell seats or make the balance negative. The unique constraint blocks duplicate entries.
- Deposits must only be approved after independently verifying the payment. Do not credit coins from a screenshot alone or from an unverified browser redirect.
- Withdrawal requests reserve coins immediately. Rejection returns the reserved coins. Approval only marks the request approved; it does not send funds.
- `credit_prize()` is a starter function. If you edit a result or need to change a previously credited prize, use a reviewed adjustment process; do not repeatedly call it for the same winner.
- Add limits, abuse checks, monitoring, and independent security review before production.

## Easypaisa, JazzCash and bank transfer

Do not assume a personal wallet account can be used as a merchant gateway. Contact each provider and ask for merchant onboarding, tournament/entry-fee eligibility, checkout/API access, webhook signing details, settlement timing, refunds/disputes and payout availability. Requirements can vary by account and business model.

For manual verification initially:
1. Player submits a deposit request with method and transaction reference.
2. Admin checks the transaction in the official provider app/dashboard/bank record.
3. Admin approves the request in the authenticated admin UI (not currently wired), which calls `review_deposit(request_id, true)`.
4. The function credits once because it only processes pending requests and writes a unique transaction reference.
5. Never store PINs, OTPs, passwords, or full card credentials.

For a gateway later, build a server-side endpoint/webhook that validates the provider's signature and amount/currency/reference, deduplicates provider transaction IDs, and only then credits the wallet. Keep secret keys on the server. A successful browser redirect is not proof of payment.

## Deployment recommendation

- Start with Supabase's free tier for development/testing, subject to its current quotas and inactivity policies.
- Host the static frontend on a free static host (for example, Cloudflare Pages or Netlify) once integrated.
- Use HTTPS, environment variables, backups, rate limits, email verification and logging.
- Free tiers may sleep, have quotas, or change terms; check the provider's current plan details before launch.

## Before production launch

- Connect UI to Supabase Auth and remove demo/localStorage money logic.
- Add admin screens that call the secured RPC functions and display request statuses.
- Add safe image upload to a private/admin-controlled storage bucket and public read policy for published assets.
- Room ID/password are stored in a separate table; the RLS policy only reveals them to joined players after `reveal_at`, or to admins. Keep this policy intact.
- Add cancelled-tournament policy, support contact, privacy policy, terms, age rules and clear refund/prize rules.
- Test authorization, duplicate requests, simultaneous joins, negative balances, replayed payment webhooks, backups and admin removal.
- Have a qualified professional review local legal, tax, payment-provider and game tournament requirements before handling real money.

## Authentication UI setup (updated)

The Vite frontend now contains Supabase Auth UI. The UI itself is code-complete, but it has not been connected to your own project or tested against live project credentials in this build environment.

1. Install Node.js LTS, then run `npm install` in the project folder.
2. Copy `.env.example` to `.env` and fill in `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` from your Supabase project's **Project Settings → API** page. Use only the public anon/publishable key in browser code. Do not use `service_role`.
3. In Supabase, go to **Authentication → Providers → Email** and enable Email provider. Make sure email confirmations are required/enabled. Wording may vary in the dashboard.
4. Under **Authentication → URL Configuration**, set the Site URL to your local Vite URL during development (usually `http://localhost:5173`). Add that URL to the Redirect URLs allow-list. Later add your actual deployed HTTPS domain too.
5. For email confirmation delivery, configure the project's email settings. Supabase's default email service may be restricted or rate-limited; for a public launch, configure a suitable SMTP provider and test delivery.
6. Run `supabase/migrations/0001_initial_schema.sql` in SQL Editor if you have not already done so.
7. Run `npm run dev`, open the local Vite URL, and test: create an account, click the verification email, sign in with email/password, request a password reset, and sign out.
8. To enable Google sign-in, go to **Authentication → Providers → Google**, enable it, add the OAuth Client ID and Client Secret from your Google Cloud OAuth setup, and configure the Supabase callback URL shown in the provider screen in Google Cloud. Add your local and deployed app URLs to Supabase's Redirect URLs allow-list. Test the entire redirect/return flow.
9. Create the first account using the signup UI, verify its email, then promote only that account to admin using its Auth UUID and the SQL command above. New signups are always created as `player` by the database trigger.

The frontend checks `profiles.role` to hide the demo admin navigation from ordinary players, but that is not a security boundary by itself. RLS and server-side checks are mandatory. In this build, the admin panel and all wallet/tournament interactions remain demo/localStorage features even for authenticated accounts. They must be replaced with database-backed queries and secure RPC calls before any public launch or real-money use.
